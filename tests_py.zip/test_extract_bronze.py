import runpy
import sys
from pathlib import Path
from unittest.mock import Mock

import pytest


SCRIPT_PATH = "/app/src/extract/extract_bronze.py"
BRONZE_BASE = Path("/app/data/bronze/open_brewery_db")


def fake_response(payload):
    response = Mock()
    response.json.return_value = payload
    response.raise_for_status.return_value = None
    return response


def test_extract_bronze_creates_versioned_output(monkeypatch, spark, run_ts, clean_test_paths):
    import requests

    page_1 = [
        {
            "id": "1",
            "name": "Brewery A",
            "brewery_type": "micro",
            "address_1": "Street 1",
            "address_2": None,
            "address_3": None,
            "city": "Portland",
            "state_province": None,
            "postal_code": "12345",
            "country": "United States",
            "longitude": "-122.6765",
            "latitude": "45.5231",
            "phone": "1234567890",
            "website_url": "https://brewery-a.com",
            "state": "Oregon",
            "street": "Street 1",
        }
    ]

    page_2 = [
        {
            "id": "2",
            "name": "Brewery B",
            "brewery_type": "brewpub",
            "address_1": "Street 2",
            "address_2": None,
            "address_3": None,
            "city": "Seattle",
            "state_province": None,
            "postal_code": "54321",
            "country": "United States",
            "longitude": "-122.3321",
            "latitude": "47.6062",
            "phone": "9999999999",
            "website_url": "https://brewery-b.com",
            "state": "Washington",
            "street": "Street 2",
        }
    ]

    responses = [
        fake_response(page_1),
        fake_response(page_2),
        fake_response([]),
    ]

    def mock_get(*args, **kwargs):
        return responses.pop(0)

    monkeypatch.setattr(requests, "get", mock_get)
    monkeypatch.setattr(sys, "argv", ["extract_bronze.py", run_ts])

    runpy.run_path(SCRIPT_PATH, run_name="__main__")

    output_path = BRONZE_BASE / f"run_ts={run_ts}"
    assert output_path.exists()

    df = spark.read.json(str(output_path))
    assert df.count() == 2

    columns = set(df.columns)
    assert "extracted_at" in columns
    assert "source" in columns
    assert "page" in columns

    rows = df.orderBy("id").collect()
    assert rows[0]["page"] == 1
    assert rows[1]["page"] == 2
    assert rows[0]["source"] == "https://api.openbrewerydb.org/v1/breweries"


def test_extract_bronze_fails_when_api_returns_no_data(monkeypatch, run_ts, clean_test_paths):
    import requests

    responses = [fake_response([])]

    def mock_get(*args, **kwargs):
        return responses.pop(0)

    monkeypatch.setattr(requests, "get", mock_get)
    monkeypatch.setattr(sys, "argv", ["extract_bronze.py", run_ts])

    with pytest.raises(ValueError, match="bronze está vazia"):
        runpy.run_path(SCRIPT_PATH, run_name="__main__")
