import runpy
import sys
from pathlib import Path

import pytest


SCRIPT_PATH = "/app/src/transform/transform_silver.py"
BRONZE_BASE = Path("/app/data/bronze/open_brewery_db")
SILVER_BASE = Path("/app/data/silver/breweries")


def test_transform_silver_creates_parquet_and_applies_rules(spark, run_ts, clean_test_paths):
    bronze_path = BRONZE_BASE / f"run_ts={run_ts}"

    input_data = [
        {
            "id": "1",
            "name": " Brewery A ",
            "brewery_type": "MICRO",
            "address_1": " Street 1 ",
            "address_2": None,
            "address_3": None,
            "city": " new york ",
            "state_province": None,
            "postal_code": "10001",
            "country": "us",
            "longitude": "-74.0060",
            "latitude": "40.7128",
            "phone": "(123) 456-7890",
            "website_url": " https://brewery-a.com ",
            "state": " new york ",
            "street": " Street 1 ",
            "source": "api",
            "page": 1,
            "extracted_at": "2026-03-18T10:00:00+00:00",
        },
        {
            "id": "1",
            "name": " Brewery A ",
            "brewery_type": "MICRO",
            "address_1": " Street 1 ",
            "address_2": None,
            "address_3": None,
            "city": " new york ",
            "state_province": None,
            "postal_code": "10001",
            "country": "us",
            "longitude": "-74.0060",
            "latitude": "40.7128",
            "phone": "(123) 456-7890",
            "website_url": " https://brewery-a.com ",
            "state": " new york ",
            "street": " Street 1 ",
            "source": "api",
            "page": 1,
            "extracted_at": "2026-03-18T10:00:00+00:00",
        }
    ]

    df_bronze = spark.createDataFrame(input_data)
    df_bronze.write.mode("overwrite").json(str(bronze_path))

    sys.argv = ["transform_silver.py", run_ts]
    runpy.run_path(SCRIPT_PATH, run_name="__main__")

    silver_path = SILVER_BASE / f"run_ts={run_ts}"
    assert silver_path.exists()

    df_silver = spark.read.parquet(str(silver_path))
    assert df_silver.count() == 1

    row = df_silver.collect()[0]

    assert "brewery_id" in df_silver.columns
    assert row["brewery_id"] == "1"
    assert row["name"] == "Brewery A"
    assert row["brewery_type"] == "micro"
    assert row["city"] == "New York"
    assert row["state"] == "New York"
    assert row["country"] == "US"
    assert row["phone"] == "1234567890"
    assert isinstance(row["latitude"], float)
    assert isinstance(row["longitude"], float)
    assert row["page"] == 1


def test_transform_silver_fails_when_bronze_is_empty(spark, run_ts, clean_test_paths):
    bronze_path = BRONZE_BASE / f"run_ts={run_ts}"

    empty_schema = "id string, name string, brewery_type string, address_1 string, address_2 string, address_3 string, city string, state_province string, postal_code string, country string, longitude string, latitude string, phone string, website_url string, state string, street string, source string, page int, extracted_at string"
    empty_df = spark.createDataFrame([], empty_schema)
    empty_df.write.mode("overwrite").json(str(bronze_path))

    sys.argv = ["transform_silver.py", run_ts]

    with pytest.raises(ValueError, match="silver está vazia"):
        runpy.run_path(SCRIPT_PATH, run_name="__main__")
