import runpy
import sys
from pathlib import Path

import pytest


SCRIPT_PATH = "/app/src/transform/aggregate_gold.py"
SILVER_BASE = Path("/app/data/silver/breweries")
GOLD_BASE = Path("/app/data/gold/breweries_by_type_location")


def test_aggregate_gold_groups_correctly(spark, run_ts, clean_test_paths):
    silver_path = SILVER_BASE / f"run_ts={run_ts}"

    input_data = [
        {
            "brewery_id": "1",
            "name": "Brewery A",
            "brewery_type": "micro",
            "address_1": "Street 1",
            "address_2": None,
            "address_3": None,
            "city": "San Diego",
            "state_province": None,
            "postal_code": "12345",
            "country": "US",
            "longitude": -117.1611,
            "latitude": 32.7157,
            "phone": "1234567890",
            "website_url": "https://a.com",
            "state": "California",
            "street": "Street 1",
            "source": "api",
            "page": 1,
            "extracted_at": "2026-03-18T10:00:00",
        },
        {
            "brewery_id": "2",
            "name": "Brewery B",
            "brewery_type": "micro",
            "address_1": "Street 2",
            "address_2": None,
            "address_3": None,
            "city": "San Diego",
            "state_province": None,
            "postal_code": "12345",
            "country": "US",
            "longitude": -117.1611,
            "latitude": 32.7157,
            "phone": "9999999999",
            "website_url": "https://b.com",
            "state": "California",
            "street": "Street 2",
            "source": "api",
            "page": 1,
            "extracted_at": "2026-03-18T10:00:00",
        },
        {
            "brewery_id": "3",
            "name": "Brewery C",
            "brewery_type": "brewpub",
            "address_1": "Street 3",
            "address_2": None,
            "address_3": None,
            "city": "San Diego",
            "state_province": None,
            "postal_code": "12345",
            "country": "US",
            "longitude": -117.1611,
            "latitude": 32.7157,
            "phone": "8888888888",
            "website_url": "https://c.com",
            "state": "California",
            "street": "Street 3",
            "source": "api",
            "page": 1,
            "extracted_at": "2026-03-18T10:00:00",
        }
    ]

    df_silver = spark.createDataFrame(input_data)
    df_silver.write.mode("overwrite").parquet(str(silver_path))

    sys.argv = ["aggregate_gold.py", run_ts]
    runpy.run_path(SCRIPT_PATH, run_name="__main__")

    gold_path = GOLD_BASE / f"run_ts={run_ts}"
    assert gold_path.exists()

    df_gold = spark.read.parquet(str(gold_path))
    rows = df_gold.collect()

    result = {
        (r["country"], r["state"], r["city"], r["brewery_type"]): r["brewery_count"]
        for r in rows
    }

    assert result[("US", "California", "San Diego", "micro")] == 2
    assert result[("US", "California", "San Diego", "brewpub")] == 1


def test_aggregate_gold_fails_when_silver_is_empty(spark, run_ts, clean_test_paths):
    silver_path = SILVER_BASE / f"run_ts={run_ts}"

    empty_schema = '''
        brewery_id string,
        name string,
        brewery_type string,
        address_1 string,
        address_2 string,
        address_3 string,
        city string,
        state_province string,
        postal_code string,
        country string,
        longitude double,
        latitude double,
        phone string,
        website_url string,
        state string,
        street string,
        source string,
        page int,
        extracted_at timestamp
    '''
    empty_df = spark.createDataFrame([], empty_schema)
    empty_df.write.mode("overwrite").parquet(str(silver_path))

    sys.argv = ["aggregate_gold.py", run_ts]

    with pytest.raises(ValueError, match="gold está vazia"):
        runpy.run_path(SCRIPT_PATH, run_name="__main__")
