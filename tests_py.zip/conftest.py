import shutil
from pathlib import Path

import pytest
from pyspark.sql import SparkSession


APP_DATA = Path("/app/data")


@pytest.fixture(scope="session")
def spark():
    spark = (
        SparkSession.builder
        .master("local[2]")
        .appName("pytest-brewery-case")
        .config("spark.sql.shuffle.partitions", "2")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")
    yield spark
    spark.stop()


@pytest.fixture
def run_ts():
    return "TEST_RUN_20260318T000000"


@pytest.fixture
def clean_test_paths(run_ts):
    paths = [
        APP_DATA / "bronze" / "open_brewery_db" / f"run_ts={run_ts}",
        APP_DATA / "silver" / "breweries" / f"run_ts={run_ts}",
        APP_DATA / "gold" / "breweries_by_type_location" / f"run_ts={run_ts}",
    ]

    for path in paths:
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)

    yield

    for path in paths:
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
